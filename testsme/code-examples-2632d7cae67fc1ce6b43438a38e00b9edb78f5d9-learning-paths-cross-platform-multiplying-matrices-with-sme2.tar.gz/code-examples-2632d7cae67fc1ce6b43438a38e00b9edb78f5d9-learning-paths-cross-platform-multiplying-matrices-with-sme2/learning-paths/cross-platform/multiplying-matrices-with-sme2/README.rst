..
  SPDX-FileCopyrightText: Copyright 2024 Arm Limited and/or its affiliates <open-source-office@arm.com>
  SPDX-License-Identifier: BSD-3-Clause-Clear

===============================================================================
SME2 matrix multiplication learning path
===============================================================================

This directory hosts the code for the
`SME2 matrix multiplication learning path <https://learn.arm.com/learning-paths/cross-platform/multiplying-matrices-with-sme2/>`_
